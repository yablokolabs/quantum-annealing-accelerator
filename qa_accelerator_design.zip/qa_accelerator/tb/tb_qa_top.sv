// Testbench for Quantum Annealing Accelerator
`timescale 1ns/1ps

module tb_qa_top();

    parameter NUM_SPINS = 8;
    parameter DATA_WIDTH = 16;

    logic clk;
    logic rst_n;
    logic start;
    logic [DATA_WIDTH*NUM_SPINS*NUM_SPINS-1:0] weight_matrix_packed;
    logic signed [DATA_WIDTH-1:0] bias_vector [NUM_SPINS-1:0];
    logic [NUM_SPINS-1:0] final_spins;
    logic done;

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Instantiate DUT
    qa_top #(
        .NUM_SPINS(NUM_SPINS),
        .DATA_WIDTH(DATA_WIDTH)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .weight_matrix_packed(weight_matrix_packed),
        .bias_vector(bias_vector),
        .final_spins(final_spins),
        .done(done)
    );

    // Test Sequence
    initial begin
        // Initialize inputs
        rst_n = 0;
        start = 0;
        weight_matrix_packed = 0;
        
        // Define a simple Max-Cut problem on a ring graph
        for (int i = 0; i < NUM_SPINS; i++) begin
            bias_vector[i] = 0;
            for (int j = 0; j < NUM_SPINS; j++) begin
                if (i == (j + 1) % NUM_SPINS || j == (i + 1) % NUM_SPINS) begin
                    weight_matrix_packed[(i*NUM_SPINS + j)*DATA_WIDTH +: DATA_WIDTH] = -16'sd1000;
                end else begin
                    weight_matrix_packed[(i*NUM_SPINS + j)*DATA_WIDTH +: DATA_WIDTH] = 16'sd0;
                end
            end
        end

        // Reset
        #20 rst_n = 1;
        #20 start = 1;

        // Wait for completion
        wait(done);
        
        $display("Annealing Finished!");
        $display("Final Spin Configuration: %b", final_spins);
        
        // Check if it's an alternating pattern
        if (final_spins == 8'b01010101 || final_spins == 8'b10101010)
            $display("Success: Optimal Max-Cut found for ring graph!");
        else
            $display("Result: Sub-optimal or local minima found.");

        #100 $finish;
    end

    // Waveform generation
    initial begin
        $dumpfile("qa_top.vcd");
        $dumpvars(0, tb_qa_top);
    end

endmodule
