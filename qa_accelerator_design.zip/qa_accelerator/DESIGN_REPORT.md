# Quantum Annealing Accelerator Chip Design Report

## Architecture Overview
The designed Quantum Annealing Accelerator is a digital implementation of a stochastic Ising machine. It utilizes probabilistic bits (p-bits) to find the ground state of an Ising Hamiltonian, which corresponds to the solution of combinatorial optimization problems.

### Key Components:
1.  **Spin Cell (`spin_cell.sv`)**: Represents a single spin or qubit. It implements a stochastic update rule where the next state is determined by the local magnetic field and a temperature-dependent noise factor.
2.  **Ising Coupler (`ising_coupler.sv`)**: Computes the local field for each spin based on the states of all other spins and the weight matrix ($J_{ij}$) and bias vector ($h_i$).
3.  **Annealing Controller (`anneal_controller.sv`)**: Manages the global annealing schedule, gradually reducing the "temperature" (noise level) to allow the system to settle into a low-energy state.
4.  **LFSR RNG (`rng_module.sv`)**: Provides independent pseudo-random numbers for each spin cell to drive the stochastic updates.
5.  **Top-Level Integration (`qa_top.sv`)**: Connects all components into a scalable accelerator chip.

## Verification Results
The design was verified using a testbench (`tb_qa_top.sv`) targeting a Max-Cut problem on a ring graph. 

- **Environment**: Icarus Verilog 11.0
- **Simulation Result**: The system successfully completes the annealing cycle. While stochastic in nature, the system explores various configurations and approaches the optimal alternating pattern (0101...) for the Max-Cut problem.
- **Waveform**: A VCD file (`qa_top.vcd`) is generated for detailed timing analysis.

## Usage Instructions
1.  **Compile**: `iverilog -g2012 rtl/*.sv tb/*.sv`
2.  **Run**: `vvp a.out`
3.  **View Waves**: Open `qa_top.vcd` in GTKWave.
