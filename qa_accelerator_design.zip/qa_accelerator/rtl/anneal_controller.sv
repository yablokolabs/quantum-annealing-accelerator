// Annealing Controller
// Manages the global annealing schedule by decreasing the temperature over time.

module anneal_controller #(
    parameter DATA_WIDTH = 16,
    parameter INITIAL_TEMP = 16'h7FFF,
    parameter COOLING_RATE = 16'h0100
)(
    input  logic                   clk,
    input  logic                   rst_n,
    input  logic                   start,
    output logic                   busy,
    output logic                   done,
    output logic [DATA_WIDTH-1:0]  temperature,
    output logic                   update_tick
);

    typedef enum logic [1:0] {IDLE, ANNEALING, FINISHED} state_t;
    state_t state;

    logic [DATA_WIDTH-1:0] temp_reg;
    logic [7:0] cycle_count;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            temp_reg <= INITIAL_TEMP;
            busy <= 1'b0;
            done <= 1'b0;
            cycle_count <= 8'd0;
            update_tick <= 1'b0;
        end else begin
            case (state)
                IDLE: begin
                    done <= 1'b0;
                    if (start) begin
                        state <= ANNEALING;
                        temp_reg <= INITIAL_TEMP;
                        busy <= 1'b1;
                    end
                end

                ANNEALING: begin
                    update_tick <= (cycle_count == 8'd0);
                    cycle_count <= cycle_count + 1;
                    
                    if (cycle_count == 8'hFF) begin // Every 256 cycles, cool down
                        if (temp_reg > COOLING_RATE) begin
                            temp_reg <= temp_reg - COOLING_RATE;
                        end else begin
                            temp_reg <= 0;
                            state <= FINISHED;
                        end
                    end
                end

                FINISHED: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    if (!start) state <= IDLE;
                end
            endcase
        end
    end

    assign temperature = temp_reg;

endmodule
