// Top-Level Quantum Annealing Accelerator Chip
// Integrates spins, couplers, and controller.

module qa_top #(
    parameter NUM_SPINS = 8,
    parameter DATA_WIDTH = 16
)(
    input  logic                   clk,
    input  logic                   rst_n,
    input  logic                   start,
    // Configuration Interface: weights are packed into a single vector
    input  logic [DATA_WIDTH*NUM_SPINS*NUM_SPINS-1:0] weight_matrix_packed,
    input  logic signed [DATA_WIDTH-1:0] bias_vector [NUM_SPINS-1:0],
    
    output logic [NUM_SPINS-1:0]   final_spins,
    output logic                   done
);

    logic [DATA_WIDTH-1:0] current_temp;
    logic update_tick;
    logic [NUM_SPINS-1:0] current_spins;
    logic [DATA_WIDTH-1:0] rand_vals [NUM_SPINS-1:0];
    logic signed [DATA_WIDTH-1:0] local_fields [NUM_SPINS-1:0];

    // Annealing Controller
    anneal_controller #(
        .DATA_WIDTH(DATA_WIDTH)
    ) ctrl_inst (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .busy(),
        .done(done),
        .temperature(current_temp),
        .update_tick(update_tick)
    );

    // Instantiate Spins and Couplers
    genvar i;
    generate
        for (i = 0; i < NUM_SPINS; i = i + 1) begin : spin_gen
            // Random Number Generator
            rng_module #(
                .WIDTH(DATA_WIDTH),
                .SEED(16'hACE1 + i*16'h1234)
            ) rng_inst (
                .clk(clk),
                .rst_n(rst_n),
                .en(update_tick),
                .rand_out(rand_vals[i])
            );

            // Coupler
            ising_coupler #(
                .NUM_SPINS(NUM_SPINS),
                .DATA_WIDTH(DATA_WIDTH)
            ) coupler_inst (
                .spins(current_spins),
                .weights_packed(weight_matrix_packed[i*NUM_SPINS*DATA_WIDTH +: NUM_SPINS*DATA_WIDTH]),
                .bias(bias_vector[i]),
                .local_field(local_fields[i])
            );

            // Spin Cell
            spin_cell #(
                .DATA_WIDTH(DATA_WIDTH)
            ) spin_inst (
                .clk(clk),
                .rst_n(rst_n),
                .update_en(update_tick),
                .local_field(local_fields[i]),
                .rand_val(rand_vals[i]),
                .temperature(current_temp),
                .spin_state(current_spins[i])
            );
        end
    endgenerate

    assign final_spins = current_spins;

endmodule
