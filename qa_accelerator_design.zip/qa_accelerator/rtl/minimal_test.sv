module minimal_test();
    initial begin
        $display("Icarus Verilog is working!");
        $finish;
    end
endmodule
