// Ising Coupler Module
// Computes the local field for a spin: I_i = sum(J_ij * sigma_j) + h_i

module ising_coupler #(
    parameter NUM_SPINS = 8,
    parameter DATA_WIDTH = 16
)(
    input  logic [NUM_SPINS-1:0]       spins,
    input  logic signed [DATA_WIDTH*NUM_SPINS-1:0] weights_packed,
    input  logic signed [DATA_WIDTH-1:0] bias,
    output logic signed [DATA_WIDTH-1:0] local_field
);

    logic signed [DATA_WIDTH-1:0] sum_val;
    logic signed [DATA_WIDTH-1:0] w;
    
    always_comb begin
        sum_val = bias;
        for (int j = 0; j < NUM_SPINS; j = j + 1) begin
            w = weights_packed[j*DATA_WIDTH +: DATA_WIDTH];
            if (spins[j]) begin
                sum_val = sum_val + w;
            end else begin
                sum_val = sum_val - w;
            end
        end
    end

    assign local_field = sum_val;

endmodule
