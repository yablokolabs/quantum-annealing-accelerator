// LFSR-based Pseudo-Random Number Generator (PRNG)
// Provides random values for the stochastic update rule.

module rng_module #(
    parameter WIDTH = 16,
    parameter SEED = 16'hACE1
)(
    input  logic             clk,
    input  logic             rst_n,
    input  logic             en,
    output logic [WIDTH-1:0] rand_out
);

    logic [WIDTH-1:0] lfsr_reg;

    // Polynomial for 16-bit LFSR: x^16 + x^14 + x^13 + x^11 + 1
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            lfsr_reg <= SEED;
        end else if (en) begin
            lfsr_reg <= {lfsr_reg[WIDTH-2:0], lfsr_reg[WIDTH-1] ^ lfsr_reg[WIDTH-3] ^ lfsr_reg[WIDTH-4] ^ lfsr_reg[WIDTH-6]};
        end
    end

    assign rand_out = lfsr_reg;

endmodule
