// Spin Cell Module
// Implements the stochastic update logic for a single spin (p-bit).
// The state transition depends on the local field (Ising Hamiltonian) and temperature.

module spin_cell #(
    parameter DATA_WIDTH = 16
)(
    input  logic                   clk,
    input  logic                   rst_n,
    input  logic                   update_en,
    input  logic signed [DATA_WIDTH-1:0] local_field, // Sum(J_ij * sigma_j) + h_i
    input  logic [DATA_WIDTH-1:0]  rand_val,    // Random threshold for stochasticity
    input  logic [DATA_WIDTH-1:0]  temperature, // Controls the annealing schedule
    output logic                   spin_state   // Current state: 0 for -1, 1 for +1
);

    // Stochastic update rule:
    // P(spin = +1) = sigmoid(beta * local_field)
    // Simplified hardware implementation: 
    // If local_field + noise > threshold, spin = 1, else 0.
    // Here we use a linear approximation for hardware efficiency.

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            spin_state <= 1'b0; // Default to -1
        end else if (update_en) begin
            // Simple thresholding logic for the p-bit update
            // Effectively: spin = (tanh(local_field / T) + random > 0)
            // For hardware, we can compare local_field with a scaled random value.
            // If local_field > 0, spin prefers +1. 
            // If local_field < 0, spin prefers -1.
            // Noise (temperature) makes it probabilistic.
            if ($signed(local_field) + $signed({1'b0, rand_val[DATA_WIDTH-2:0]}) - $signed({1'b0, temperature}) > 0) begin
                spin_state <= 1'b1;
            end else begin
                spin_state <= 1'b0;
            end
        end
    end

endmodule
